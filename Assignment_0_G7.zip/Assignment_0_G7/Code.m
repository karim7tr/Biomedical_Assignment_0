%% Biomedical Robotics %%
%% Assignment_0
%% Team Members: 
%% Karim Triki s5528602
%% Roumaissa Benkredda s5434673
%% Ines Haouala s5483776
%% ----------START----------%% 

% Load data from three different datasets...
load('data1.mat');
load('data2.mat');
load('data3.mat');

% Define sampling frequencies for each dataset....
sampling_frequency_data1 = 2000;  % Hz
sampling_frequency_data2 = 166;   % Hz
sampling_frequency_data3 = 250;   % Hz

% Create time vectors for each dataset.....
time_vector_data1 = (0:length(data1)-1) / sampling_frequency_data1;
time_vector_data2 = (0:size(data2, 2)-1) / sampling_frequency_data2;
time_vector_data3 = (0:size(data3, 2)-1) / sampling_frequency_data3;

% Plot each dataset in the time domain......
figure;

% Dataset 1 - Electromyography (EMG)
subplot(3, 2, 1);
plot(time_vector_data1, data1);
xlabel('Time: sec');
ylabel('Amplitude');
title('Dataset 1: Electromyography (EMG)');

% Compute and plot the single-sided frequency domain for Dataset 1........
subplot(3, 2, 2);
N1 = length(data1);
frequencies1 = (0:N1/2-1) * (sampling_frequency_data1 / N1);
amplitudes1 = abs(fft(data1)) / N1;
amplitudes1_single_sided = amplitudes1(1:N1/2);
plot(frequencies1, amplitudes1_single_sided);
xlabel('Frequency: Hz');
ylabel('Amplitude');
title('Frequency Domain - Dataset 1 (Single-Sided)');

% Dataset 2 - Motion Data (Multiple Channels)
subplot(3, 2, 3);
plot(time_vector_data2, data2(1, :), 'b-', 'LineWidth', 2);  % Blue line for Channel 1
hold on;
plot(time_vector_data2, data2(2, :), 'r-', 'LineWidth', 2);  % Red line for Channel 2
xlabel('Time: sec');
ylabel('Amplitude');
title('Dataset 2: Motion Data (Channels 1 and 2)');
legend('Channel 1', 'Channel 2');

% Compute and plot the single-sided frequency domain for Dataset 2
subplot(3, 2, 4);
N2 = size(data2, 2);
frequencies2 = (0:N2/2-1) * (sampling_frequency_data2 / N2);
amplitudes2_channel1 = abs(fft(data2(1, :))) / N2;
amplitudes2_channel2 = abs(fft(data2(2, :))) / N2;
amplitudes2_channel1_single_sided = amplitudes2_channel1(1:N2/2);
amplitudes2_channel2_single_sided = amplitudes2_channel2(1:N2/2);
plot(frequencies2, amplitudes2_channel1_single_sided, 'b-', 'LineWidth', 2);
hold on;
plot(frequencies2, amplitudes2_channel2_single_sided, 'r-', 'LineWidth', 2);
xlabel('Frequency: Hz');
ylabel('Amplitude');
title('Frequency Domain - Dataset 2 (Single-Sided)');
legend('Channel 1', 'Channel 2');

% Dataset 3 - Electroencephalography (EEG) signals
subplot(3, 2, 5);
plot(time_vector_data3, data3);
xlabel('Time: sec');
ylabel('Amplitude');
title('Dataset 3: Electroencephalography (EEG) Signals');

% Compute and plot the single-sided frequency domain for Dataset 3
subplot(3, 2, 6);
N3 = size(data3, 2);
frequencies3 = (0:N3/2-1) * (sampling_frequency_data3 / N3);
amplitudes3 = abs(fft(data3)) / N3;
amplitudes3_single_sided = amplitudes3(1:N3/2);
plot(frequencies3, amplitudes3_single_sided);
xlabel('Frequency: Hz');
ylabel('Amplitude');
title('Frequency Domain - Dataset 3 (Single-Sided)'); % ma daiiiiiiiiiiiiiiiiiiii
% " Non lo so perché all'improvviso All'improvviso" 
% forse, se facciamo *10^4 possiamo vedere la differenza
%  sì, lo so, dovremmo tagliare l'asse x a frequenze più basse per mostrare il contenuto del grafico, ma....¯\_(ツ)_/¯

% Adjust layout
sgtitle('Data Plots and Frequency Domain (Single-Sided)');  % Common title for all subplots

%% __________________________GAME OVER_______________________________________
%% SEE YOU IN NEXT ASSIGNMENT!!  :')
